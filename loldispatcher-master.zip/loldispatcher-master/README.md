# loldispatcher
Decides who gets basic stats, who gets advanced, and accounts as necessary.
